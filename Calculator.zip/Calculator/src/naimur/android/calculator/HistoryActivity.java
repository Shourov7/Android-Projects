package naimur.android.calculator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class HistoryActivity extends Activity {
	private TextView text = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	protected void onStart() {
		setContentView(R.layout.activity_history);
		super.onStart();
	}
	
	public void LoadHistory ()
	{
		SharedPreferences sharedPref = getSharedPreferences("MyData", Context.MODE_PRIVATE);
    	String temp = sharedPref.getString("history", "");
    	text.setText(temp);
	}
	
	@Override
	protected void onResume() {
		this.text = (TextView) this.findViewById(R.id.historyTextView);
		text.setMovementMethod(new ScrollingMovementMethod());
		LoadHistory ();
		super.onResume();
	}
	
	public void BackToMain (View v)
	{
		finish ();
	}
}
