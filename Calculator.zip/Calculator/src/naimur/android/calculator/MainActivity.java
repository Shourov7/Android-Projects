package naimur.android.calculator;

import java.math.BigDecimal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private TextView upperDisplay = null;
	private TextView lowerDisplay = null;
	private double result = 0, memoryPlusCalled = 0, memory, firstNumber, secondNumber;
	private int operator = 0, dotPressed = 0, equalPressed = 0, pORm = 0, operatorPressed = 0, numberPressed = 0;
	private String firstString = "", secondString = "", upperString = "", lowerString = "", equation = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	setContentView(R.layout.activity_main);
    	this.upperDisplay = (TextView) this.findViewById(R.id.upperText);
    	this.lowerDisplay = (TextView) this.findViewById(R.id.lowerText);
        super.onCreate(savedInstanceState);
    }
    
    @Override
    protected void onStart() {	
    	super.onStart();
    }
    
    @Override
    protected void onResume() {
    	super.onResume();
    }
    
    @Override
    protected void onSaveInstanceState(Bundle outState) {
    	super.onSaveInstanceState(outState);
    	upperString = upperDisplay.getText().toString();
    	lowerString = lowerDisplay.getText().toString();
    	outState.putString("upperString1", upperString);
    	outState.putString("lowerString1", lowerString);
    	outState.putString("firstString1", firstString);
    	outState.putInt("operator1", operator);
    	outState.putInt("dotPressed1", dotPressed);
    	outState.putInt("equalPressed1", equalPressed);
    	outState.putInt("pORm1", pORm);
    	outState.putInt("numberPressed1", numberPressed);
    	outState.putInt("operatorPressed1", operatorPressed);
    	outState.putDouble("result1", result);
    	outState.putDouble("memory1", memoryPlusCalled);
    	
    }
    
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
    	super.onRestoreInstanceState(savedInstanceState);
    	upperDisplay.setText(savedInstanceState.getString("upperString1"));
    	lowerDisplay.setText(savedInstanceState.getString("lowerString1"));
    	firstString = savedInstanceState.getString("firstString1");
    	operator = savedInstanceState.getInt("operator1");
    	dotPressed = savedInstanceState.getInt("dotPressed1");
    	equalPressed = savedInstanceState.getInt("equalPressed1");
    	pORm = savedInstanceState.getInt("pORm1");
    	numberPressed = savedInstanceState.getInt("numberPressed1");
    	operatorPressed = savedInstanceState.getInt("operatorPressed1");
    	result = savedInstanceState.getDouble("result1");
    	memoryPlusCalled = savedInstanceState.getDouble("memory1");
    	
    }
    
    public void HistoryClicked (View v)
    {
    	Intent i = new Intent (MainActivity.this, HistoryActivity.class);
    	startActivity(i);
    }
    
    public void SaveInMemory ()
    {
    	SharedPreferences sharedPref = getSharedPreferences("MyData", Context.MODE_PRIVATE);
    	String temp = sharedPref.getString("history", "");
    	temp = temp + "\n" + equation;
    	
    	SharedPreferences.Editor editor = sharedPref.edit();
    	editor.putString("history", temp);
    	editor.commit();
    }
    
    public void SaveMemory ()
    {
    	SharedPreferences sharedPref = getSharedPreferences("myMemory", Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = sharedPref.edit();
    	editor.putString("memory", String.valueOf(memory));
    	editor.commit ();
    }
    
    public String GetMemory ()
    {
    	SharedPreferences sharedPref = getSharedPreferences("myMemory", Context.MODE_PRIVATE);
    	return sharedPref.getString("memory", "");
    }
    
    public void BackClicked (View v)
    {
    	try {
    		if (!lowerDisplay.getText().toString().equals(""))
    		{
	    		lowerString = lowerDisplay.getText().toString();
	    		if (lowerString.charAt(lowerString.length() - 1) == '.')
	    			dotPressed = 0;
	    		lowerString = lowerString.substring(0, lowerString.length() - 1);
	    		lowerDisplay.setText(lowerString);
	    		numberPressed--;
    		}
    		else {
    			Toast toast = Toast.makeText(getApplicationContext(), "Text Field is Empty", Toast.LENGTH_SHORT);
	    		toast.show ();
	    		numberPressed = 0;
    		}
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void ClearClicked (View v)
    {
    	try {
    		lowerDisplay.setText("");
    		upperDisplay.setText("");
    		result = 0;
    		firstNumber = 0;
    		secondNumber = 0;
    		operator = 0;
    		dotPressed = 0;
    		equalPressed = 0;
    		pORm = 0;
    		firstString = "";
    		secondString = "";
    		upperString = "";
    		lowerString = "";
    		operatorPressed = 0;
    		numberPressed = 0;
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void NumberClicked (View v)
    {
    	try {
    		if (numberPressed < 16)
    		{
		    	Button btn = (Button) v;
		    	if (lowerDisplay.getText().equals(String.valueOf(result)) ||
		    			lowerDisplay.getText().equals(String.valueOf(memory)) ||
		    			lowerDisplay.getText().equals(String.valueOf("0")) ||
		    			memoryPlusCalled != 0)
		    	{
		    		if (lowerDisplay.getText().equals("0"))
	    				numberPressed = 0;
		    		
		    		if (dotPressed == 0)
		    			lowerDisplay.setText(btn.getText().toString());
		    		else {
		    			lowerDisplay.setText(lowerDisplay.getText() + btn.getText().toString());
		    		}
		    		memoryPlusCalled = 0;
		    	}
		    	else {
		    		lowerDisplay.setText(lowerDisplay.getText() + btn.getText().toString());
		    	}
		    	numberPressed++;
    		}
    		else
    		{
    			Toast toast = Toast.makeText(getApplicationContext(), "Maximum Allowed Digits Are 16", Toast.LENGTH_SHORT);
	    		toast.show ();
    		}
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void DotClicked (View v)
    {
    	try {
	    	Button btn = (Button) v;
	    	if (dotPressed != 0 || lowerDisplay.getText().equals(String.valueOf(result * -1)))
	    	{
	    		Toast toast = Toast.makeText(getApplicationContext(), "Dot Can Not Be Added More Than Once", Toast.LENGTH_SHORT);
	    		toast.show ();
	    	}
	    	else if (lowerDisplay.getText().equals(String.valueOf(result)) ||
	    			lowerDisplay.getText().equals(String.valueOf(memory)) ||
	    			lowerDisplay.getText().equals(""))
	    	{
	    		lowerDisplay.setText("0" + btn.getText().toString());
	    		dotPressed++;
	    		numberPressed++;
	    	}
	    	else {
	    		lowerDisplay.setText(lowerDisplay.getText() + btn.getText().toString());
	    		dotPressed++;
	    	}
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void Calculation ()
    {
    	try {
    		if (lowerDisplay.getText().toString().equals("") || firstString.equals(""))
    		{
    			Toast toast = Toast.makeText(getApplicationContext(), "One or Both Operands Are Needed", Toast.LENGTH_SHORT);
	    		toast.show ();
    		}
    		else {
	    		dotPressed = 0;
		    	firstNumber = Double.parseDouble(firstString);
		    	
		    	if (equalPressed == 0)
		    	{
		    		secondNumber = Double.parseDouble(lowerDisplay.getText().toString());
		    		switch (operator)
		    		{
		    		case 1: result = new BigDecimal(firstNumber + secondNumber).setScale(2,
		    				BigDecimal.ROUND_HALF_UP).doubleValue();
		    		equation = upperDisplay.getText().toString() + " " + lowerDisplay.getText().toString() + " = " + String.valueOf(result);
		    		upperDisplay.setText("");
		    		lowerDisplay.setText(String.valueOf(result));
		    		SaveInMemory ();
		    		equalPressed++;
		    		break;
		    		case 2: result = new BigDecimal(firstNumber - secondNumber).setScale(2,
		    				BigDecimal.ROUND_HALF_UP).doubleValue();
		    		equation = upperDisplay.getText().toString() + " " + lowerDisplay.getText().toString() + " = " + String.valueOf(result);
		    		upperDisplay.setText("");
		    		lowerDisplay.setText(String.valueOf(result));
		    		SaveInMemory ();
		    		equalPressed++;
		    		break;
		    		case 3: result = new BigDecimal(firstNumber * secondNumber).setScale(2,
		    				BigDecimal.ROUND_HALF_UP).doubleValue();
		    		equation = upperDisplay.getText().toString() + " " + lowerDisplay.getText().toString() + " = " + String.valueOf(result);
		    		upperDisplay.setText("");
		    		lowerDisplay.setText(String.valueOf(result));
		    		SaveInMemory ();
		    		equalPressed++;
		    		break;
		    		default: if (secondNumber != 0)
		    			{
			    			result = new BigDecimal(firstNumber / secondNumber).setScale(2,
			    				BigDecimal.ROUND_HALF_UP).doubleValue();
			    			equation = upperDisplay.getText().toString() + " " + lowerDisplay.getText().toString() + " = " + String.valueOf(result);
			    			upperDisplay.setText("");
			    			lowerDisplay.setText(String.valueOf(result));
			    			SaveInMemory ();
			    			equalPressed++;
			    			break;
		    			}
		    		else {
		    			Toast toast = Toast.makeText(getApplicationContext(), "0 Can Not Be A Divisor", Toast.LENGTH_SHORT);
			    		toast.show ();
			    		break;
		    			}
		    		}
		    	}
		    	else {
		    		switch (operator)
		    		{
		    		case 1: firstNumber = Double.parseDouble(lowerDisplay.getText().toString());
		    		result = new BigDecimal(firstNumber + secondNumber).setScale(2,
		    				BigDecimal.ROUND_HALF_UP).doubleValue();
		    		equation = lowerDisplay.getText().toString() + " + " + String.valueOf(secondNumber) + " = " + String.valueOf(result);
		    		upperDisplay.setText("");
		    		lowerDisplay.setText(String.valueOf(result));
		    		SaveInMemory ();
		    		break;
		    		case 2: firstNumber = Double.parseDouble(lowerDisplay.getText().toString());
		    		result = new BigDecimal(firstNumber - secondNumber).setScale(2,
		    				BigDecimal.ROUND_HALF_UP).doubleValue();
		    		equation = lowerDisplay.getText().toString() + " - " + String.valueOf(secondNumber) + " = " + String.valueOf(result);
		    		upperDisplay.setText("");
		    		lowerDisplay.setText(String.valueOf(result));
		    		SaveInMemory ();
		    		break;
		    		case 3: firstNumber = Double.parseDouble(lowerDisplay.getText().toString());
		    		result = new BigDecimal(firstNumber * secondNumber).setScale(2,
		    				BigDecimal.ROUND_HALF_UP).doubleValue();
		    		equation = lowerDisplay.getText().toString() + " * " + String.valueOf(secondNumber) + " = " + String.valueOf(result);
		    		upperDisplay.setText("");
		    		lowerDisplay.setText(String.valueOf(result));
		    		SaveInMemory ();
		    		break;
		    		default: if (secondNumber != 0)
		    		{
			    			firstNumber = Double.parseDouble(lowerDisplay.getText().toString());
			    		result = new BigDecimal(firstNumber / secondNumber).setScale(2,
			    				BigDecimal.ROUND_HALF_UP).doubleValue();
			    		equation = lowerDisplay.getText().toString() + " / " + String.valueOf(secondNumber) + " = " + String.valueOf(result);
			    		upperDisplay.setText("");
			    		lowerDisplay.setText(String.valueOf(result));
			    		SaveInMemory ();
			    		break;
		    		}
		    		else {
		    			Toast toast = Toast.makeText(getApplicationContext(), "0 Can Not Be A Divisor", Toast.LENGTH_SHORT);
			    		toast.show ();
			    		break;
		    		}
		    		}
		    	}
	    	}
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void EqualClicked (View v)
    {
    	try
    	{
    		Calculation ();
    		operatorPressed = 0;
    		numberPressed = 0;
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void OperatorClicked (View v)
    {
    	try {
    		if (operatorPressed != 0)
    			Calculation();
    		
    		operatorPressed++;
    		numberPressed = 0;
    		dotPressed = 0;
	    	Button btn = (Button) v;
	    	if (btn.getText().toString().equals("+"))
	    		operator = 1;
	    	else if (btn.getText().toString().equals("-"))
	    		operator = 2;
	    	else if (btn.getText().toString().equals("*"))
	    		operator = 3;
	    	else operator = 4;
	    	
	    	if (!lowerDisplay.getText().equals("") && firstString.equals(""))
	    	{
	    		equalPressed = 0;
	    		firstString = lowerDisplay.getText().toString();
	    		lowerDisplay.setText("");
	    		upperDisplay.setText(firstString + " " + btn.getText().toString());
	    	}
	    	else if (lowerDisplay.getText().equals("") && !firstString.equals("")) {
	    		equalPressed = 0;
	    		upperDisplay.setText(firstString + " " + btn.getText().toString());
	    	}
	    	else if (!lowerDisplay.getText().equals("") && !firstString.equals("")) {
	    		equalPressed = 0;
	    		firstString = lowerDisplay.getText().toString();
	    		lowerDisplay.setText("");
	    		upperDisplay.setText(firstString + " " + btn.getText().toString());
	    	}
	    	else {
	    		Toast toast = Toast.makeText(getApplicationContext(), "An Operand Have to Set Before An Operator", Toast.LENGTH_SHORT);
	    		toast.show ();
	    	}
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }

    public void MemoryCalled (View v)
    {
    	try {
    		numberPressed = 0;
    		lowerDisplay.setText ("");
    		if (GetMemory().equals(""))
			{
				memory = 0;
			}
			else {
				memory = Double.parseDouble(GetMemory());
			}
    		lowerDisplay.setText(String.valueOf(memory));
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void MemoryClean (View v)
    {
    	try {
    		if (lowerDisplay.getText().toString().equals("") || Double.parseDouble(lowerDisplay.getText().toString()) == memory)
    		{
    			lowerDisplay.setText("");
    		}
    		memory = 0;
    		SaveMemory();
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void MemoryPlus (View v)
    {
    	try {
    		if (!lowerDisplay.getText().toString().equals(""))
    		{
    			if (GetMemory().equals(""))
    			{
    				memory = 0;
    			}
    			else {
    				memory = Double.parseDouble(GetMemory());
    			}
    			memory += Double.parseDouble(lowerDisplay.getText().toString());
    			SaveMemory();
    			memoryPlusCalled = 1;
    		}
    		numberPressed = 0;
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
    
    public void PlusORMinus (View v)
    {
    	try {
    		if (lowerDisplay.getText().toString().equals(""))
    		{
    			Toast toast = Toast.makeText(getApplicationContext(), "Operand Needed", Toast.LENGTH_SHORT);
	    		toast.show ();
    		}
    		else if (!lowerDisplay.getText().toString().equals("0")) {
	    		if (pORm == 0)
	    		{
	    			lowerDisplay.setText("-" + lowerDisplay.getText().toString());
	    			pORm = 1;
	    		}
	    		else
	    		{
	    			String temp = lowerDisplay.getText().toString();
	    			temp = temp.substring(1);
	    			lowerDisplay.setText(temp);
	    			pORm = 0;
	    		}
    		}
    	}
    	catch (Exception e)
    	{
    		Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
    	}
    }
}
