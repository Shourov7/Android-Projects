/** Automatically generated file. DO NOT MODIFY */
package naimur.android.calculator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}