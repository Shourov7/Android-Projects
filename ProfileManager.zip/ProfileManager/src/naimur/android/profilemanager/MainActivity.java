package naimur.android.profilemanager;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends Activity implements SensorEventListener {
	SensorManager sensorManager;
	Sensor proximity, accelerometer;
	AudioManager audioManager;
	float prox, xAccel, yAccel, zAccel;
	String flag = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		proximity = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
		accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		super.onCreate(savedInstanceState);
	}
	
	@Override
	protected void onResume() {
		sensorManager.registerListener(this, accelerometer, sensorManager.SENSOR_DELAY_NORMAL);
		sensorManager.registerListener(this, proximity, sensorManager.SENSOR_DELAY_NORMAL);
		setContentView(R.layout.activity_main);
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		sensorManager.unregisterListener(this);
		super.onPause();
	}
	

	@Override
	public void onSensorChanged(SensorEvent event) {
		try {
			Sensor sens = event.sensor;
			
			if (sens.getType() == Sensor.TYPE_PROXIMITY)
			{
				prox = event.values[0];
			}
			
			if (sens.getType()== Sensor.TYPE_ACCELEROMETER)
			{
				xAccel = event.values[0];
				yAccel = event.values[1];
				zAccel = event.values[2];
			}
			
			if (zAccel > 8 && !flag.equals("Normal"))
			{
				Log.d("Value", String.valueOf(prox));
				Log.d("x Value", String.valueOf(xAccel));
				Log.d("y Value", String.valueOf(yAccel));
				Log.d("z Value", String.valueOf(zAccel));
				
				audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
				flag = "Normal";
				Toast toast = Toast.makeText(getApplicationContext(), "Normal Mode Activated", Toast.LENGTH_SHORT);
	    		toast.show ();
			}
			else if (zAccel < -8 && !flag.equals("Silent"))
			{
				
				Log.d("Value", String.valueOf(prox));
				Log.d("x Value", String.valueOf(xAccel));
				Log.d("y Value", String.valueOf(yAccel));
				Log.d("z Value", String.valueOf(zAccel));
				audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
				flag = "Silent";
				Toast toast = Toast.makeText(getApplicationContext(), "Silent Mode Activated", Toast.LENGTH_SHORT);
	    		toast.show ();
			}
			else if ((yAccel > 8 || yAccel < -8) && prox != 0 && !flag.equals("Normal"))
			{
				Log.d("Value", String.valueOf(prox));
				Log.d("x Value", String.valueOf(xAccel));
				Log.d("y Value", String.valueOf(yAccel));
				Log.d("z Value", String.valueOf(zAccel));
				audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
				flag = "Normal";
				Toast toast = Toast.makeText(getApplicationContext(), "Normal Mode Activated", Toast.LENGTH_SHORT);
	    		toast.show ();
			}
			else if ((yAccel > 8 || yAccel < -8) && prox == 0 && !flag.equals("Vibrate"))
			{
				Log.d("Value", String.valueOf(prox));
				Log.d("x Value", String.valueOf(xAccel));
				Log.d("y Value", String.valueOf(yAccel));
				Log.d("z Value", String.valueOf(zAccel));
				audioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
				flag = "Vibrate";
				Toast toast = Toast.makeText(getApplicationContext(), "Vibrate Mode Activated", Toast.LENGTH_SHORT);
	    		toast.show ();
			}
			else {
				//Toast toast = Toast.makeText(getApplicationContext(), "No Mode Is Selected For This Position", Toast.LENGTH_SHORT);
	    		//toast.show ();
			}
		}
		catch (Exception e)
		{
			Toast toast = Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT);
    		toast.show ();
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}
}
