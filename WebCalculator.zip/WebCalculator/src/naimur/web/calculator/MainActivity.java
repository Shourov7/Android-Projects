package naimur.web.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
	WebView webView = null; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		webView = (WebView) findViewById(R.id.webView1);
		WebSettings webSettings = webView.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webView.addJavascriptInterface(new WebAppInterface (this), "Android");
	}
	
	@Override
	protected void onResume() {
		webView.loadUrl("file:///android_asset/web_calc.html");
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		webView.stopLoading();
		super.onPause();
	}
}
