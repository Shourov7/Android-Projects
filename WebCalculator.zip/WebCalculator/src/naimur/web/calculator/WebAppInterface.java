package naimur.web.calculator;

import android.content.Context;
import android.widget.Toast;

public class WebAppInterface {
	MainActivity mainActivity = null;
	private String number = "";
	private double initial = 0;
	private String operator = "";
	
	public WebAppInterface(Context c) {
		mainActivity = (MainActivity) c;
	}
	
	public void addNum (String num)
	{
		number += num;
	}
	
	public void addOp (String op)
	{
		if (!number.equals(""))
		{
			if (op.equals("+"))
			{
				initial += Double.parseDouble(number);
				operator = "+";
			}
			else if (op.equals("-"))
			{
				if (initial == 0)
				{
					initial += Double.parseDouble(number);
				}
				else
				{
					initial -= Double.parseDouble(number);
				}
				operator = "-";
			}
			else if (op.equals("*"))
			{
				if (initial == 0)
				{
					initial += Double.parseDouble(number);
				}
				else
				{
					initial *= Double.parseDouble(number);
				}
				operator = "*";
			}
			else
			{
				if (initial == 0)
				{
					initial += Double.parseDouble(number);
				}
				else
				{
					if (number.equals("0"))
					{
						Toast toast = Toast.makeText(mainActivity, "0 Cannot Be A Divider", Toast.LENGTH_SHORT);
			    		toast.show ();
						return;
					}
					else
						initial /= Double.parseDouble(number);
				}
				operator = "/";
			}
			number = "";
		}
	}
	
	public String getResult ()
	{
		if (!number.equals(""))
		{
			if (operator.equals("+"))
				initial += Double.parseDouble(number);
			else if (operator.equals("-"))
				initial -= Double.parseDouble(number);
			else if (operator.equals("*"))
				initial *= Double.parseDouble(number);
			else if (operator.equals("/"))
			{
				if (number.equals("0"))
				{
					Toast toast = Toast.makeText(mainActivity, "0 Cannot Be A Divider", Toast.LENGTH_SHORT);
		    		toast.show ();
		    		return "";
				}
				else
					initial /= Double.parseDouble(number);
			}
			else initial = Double.parseDouble(number);
		}
		
		String temp = Double.toString(initial);
		initial = 0;
		operator = "";
		number = "";
		return temp;
	}
}
